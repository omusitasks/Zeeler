###############################################
#          SOURCE CODE FOR CHAPTER 4          #
###############################################

# LOAD PACKLAGES ----

# load mlr library for machine learning
library(mlr)

# Load the tidyverse library(that has packages for data manipulation and visualization)
library(tidyverse)


# LOAD DATA ----
#install.packages("titanic")
install.packages("titanic", repos = "http://cran.us.r-project.org",)

# The code below reads the titanic_train dataset from the "titanic" package 
data(titanic_train, package = "titanic")

# The next line stores titanic_train dataset into titanicTib tibble object. 
titanicTib <- as_tibble(titanic_train)

# diplays the titanicTib tibble
titanicTib

# CLEAN DATA ----
# The below line creates a vector of factor variables to be used in a model
fctrs <- c("Survived", "Sex", "Pclass")

titanicClean <- titanicTib %>%
  # Mutates the variables in fctrs to factors
  mutate_at(.vars = fctrs, .funs = factor) %>% 
  # Creates a new variable called FamSize by summing the values of SibSp and Parch
  mutate(FamSize = SibSp + Parch) %>%
  # Selects only the variables Survived, Pclass, Sex, Age, Fare, and FamSize
  select(Survived, Pclass, Sex, Age, Fare, FamSize)

# prints the dataset results
titanicClean

# PLOT DATA ----
#The line of code below gathers the columns of the titanicClean dataset into two columns, 
#"Variable" and "Value", with the exception of the Survived column
titanicUntidy <- gather(titanicClean, key = "Variable", value = "Value", 
                        -Survived)
# displays the results of titanicUntidy object
titanicUntidy 

titanicUntidy %>%
  #Filter the titanicUntidy dataset to only consider the 
  #Variables that are not "Pclass" and not "Sex". 
  filter(Variable != "Pclass" & Variable != "Sex") %>%
  
  #Construct a ggplot object, with Survived as the x-axis and Value as the y-axis. 
  ggplot(aes(Survived, as.numeric(Value))) +
  
  #Facet the plot by Variable, allowing each facet to have a free y-axis.
  facet_wrap(~ Variable, scales = "free_y") +
  
  #Plot a violin plot with the quantiles 0.25, 0.5 and 0.75. 
  geom_violin(draw_quantiles = c(0.25, 0.5, 0.75)) +
  
  #the plot uses a black and white theme.
  theme_bw()

titanicUntidy %>%
  # Filter the dataframe "titanicUntidy" for only rows with the variables "Pclass" or "Sex"
  filter(Variable == "Pclass" | Variable == "Sex") %>%
  
  # Create a ggplot object using the filtered dataframe, with the fill set to Survived
  ggplot(aes(Value, fill = Survived)) +
  
  # Facet the graph by Variable, with the x scale being free
  facet_wrap(~ Variable, scales = "free_x") +
  
  # Plot the graph using geom_bar in a position fill
  geom_bar(position = "fill") +
  
  # Set the theme to black and white
  theme_bw()

# Create a classification task using the titanicClean dataset and target variable "Survived"
titanicTask <- makeClassifTask(data = titanicClean, target = "Survived")

# Create a logistic regression learner with a predict type of "prob"
logReg <- makeLearner("classif.logreg", predict.type = "prob")

# Train the logistic regression model using the titanicTask dataset
logRegModel <- train(logReg, titanicTask)
# COUNT MISSING VALUES IN Age VARIABLE ----

# Extract the Age column from the titanicClean data set.
titanicClean$Age

# Count the number of missing values in the Age column of the titanicClean data set.
sum(is.na(titanicClean$Age))

# IMPUTE MISSING VALUES ----

# Impute the Age column in the titanicClean dataset using the mean value
imp <- impute(titanicClean, cols = list(Age = imputeMean()))

# Sum the amount of NA values in the Age column in the titanicClean dataset
sum(is.na(titanicClean$Age))

# Sum the amount of NA values in the Age column in the imp dataset
sum(is.na(imp$data$Age))


# CREATE TASK WITH IMPUTED DATA AND TRAIN MODEL ----


#Create a classification task based on the Titanic dataset
titanicTask <- makeClassifTask(data = imp$data, target = "Survived")

#Train a logistic regression model using the Titanic task
logRegModel <- train(logReg, titanicTask)


# WRAP LEARNER ----

# This line of code creates an imputation wrapper for the logistic regression model (classif.logreg) 
# and set the imputation method for the Age column to be mean imputation 
logRegWrapper <- makeImputeWrapper("classif.logreg",
                                   cols = list(Age = imputeMean()))

# display logRegWrapper object
logRegWrapper

# CROSS-VALIDATE ----

#The code below creates a 10-fold cross validation resampling object with 50 repetitions, stratified by the class variable
kFold <- makeResampleDesc(method = "RepCV", folds = 10, reps = 50, stratify = TRUE)

#This line of code performs the resampling using the logRegWrapper, the titanicTask dataset, the resampling object kFold, and the measures of accuracy, false positive rate, and false negative rate
logRegwithImpute <- resample(logRegWrapper, titanicTask, resampling = kFold, measures = list(acc, fpr, fnr))

#Print the results of the resampling
logRegwithImpute

# EXTRACT ODDS RATIOS

# Get the learner model from the logRegModel
logRegModelData <- getLearnerModel(logRegModel)

# Print the coefficients of the logRegModelData
coef(logRegModelData)

# Perform an Exponential Transformation on the 
# coefficients of the logRegModelData and print the Odds Ratios
exp(cbind(Odds_Ratio = coef(logRegModelData), confint(logRegModelData)))

# USING THE MODEL TO MAKE PREDICTIONS ----

# Load the titanic test data set from the titanic package
data(titanic_test, package = "titanic")

# Convert the titanic test data set into a tibble
titanicNew <- as_tibble(titanic_test)

# Create a new variable FamSize, which is the sum of SibSp and Parch, then select only the variables Pclass, Sex, Age, Fare and FamSize
titanicNewClean <- titanicNew %>%
  mutate_at(.vars = c("Sex", "Pclass"), .funs = factor) %>%
  mutate(FamSize = SibSp + Parch) %>%
  select(Pclass, Sex, Age, Fare, FamSize)

# Use the logRegModel model to predict the data in titanicNewClean
predict(logRegModel, newdata = titanicNewClean)



# EXERCISES ----
# 1

#filter the titanicUntidy dataset using the filter function to select all the rows where the Variable column is not equal to "Pclass" or does not equal "Sex"
titanicUntidy %>%
  filter(Variable != "Pclass" & Variable != "Sex") %>%
  
  #create a ggplot object using the Survived column for the x axis, as well as the Value column for the y axis
  ggplot(aes(Survived, as.numeric(Value))) +
  
  #create facets based on the Variable column, and set the scales to free_y
  facet_wrap(~ Variable, scales = "free_y") +
  
  #add a violin plot to the graph, with the quantiles set to 0.25, 0.5, and 0.75
  geom_violin(draw_quantiles = c(0.25, 0.5, 0.75)) +
  
  #add a point plot with an alpha of 0.05 and size 3
  geom_point(alpha = 0.05, size = 3) +
  
  #set the theme to be black and white
  theme_bw()


# 2
titanicUntidy %>%
  # filter the data frame titanicUntidy by the variable "Pclass" and "Sex"
  filter(Variable == "Pclass" | Variable == "Sex") %>%
  
  # create a ggplot object with the data frame and use the variables Value and Survived for the aesthetics
  ggplot(aes(Value, fill = Survived)) +
  
  # create a facet wrap for the Variable and set the scales to "free_x"
  facet_wrap(~ Variable, scales = "free_x") +
  
  # add a geom_bar layer and set the position to "dodge"
  geom_bar(position = "dodge") +
  
  # add black and white theme
  theme_bw()


titanicUntidy %>%
  # filter the data frame titanicUntidy by the variable "Pclass" and "Sex"
  filter(Variable == "Pclass" | Variable == "Sex") %>%
  
  # create a ggplot object with the data frame and use the variables Value and Survived for the aesthetics
  ggplot(aes(Value, fill = Survived)) +
  
  # create a facet wrap for the Variable and set the scales to "free_x"
  facet_wrap(~ Variable, scales = "free_x") +
  
  # add a geom_bar layer and set the position to "stack"
  geom_bar(position = "stack") +
  
  # add black and white theme
  theme_bw()

# 3

#Selects the titanicClean dataset and excludes the Fare column
titanicNoFare <- select(titanicClean, -Fare)

#Creates a classification task using the titanicNoFare dataset and the target variable Survived
titanicNoFareTask <- makeClassifTask(data = titanicNoFare, 
                                     target = "Survived")

#Resamples the logRegWrapper using the titanicNoFareTask dataset and measures accuracy, false positive rate and false negative rate
logRegNoFare <- resample(logRegWrapper, titanicNoFareTask, 
                         resampling = kFold, 
                         measures = list(acc, fpr, fnr))

#Prints the results of the resampling
logRegNoFare

# 4


# Splits the "Name" column of the "titanicTib" dataset by the delimiter "." and creates a vector of surnames.
surnames <- map_chr(str_split(titanicTib$Name, "\\."), 1)

# Splits the vector of surnames by the delimiter ", " and creates a vector of salutations.
salutations <- map_chr(str_split(surnames, ", "), 2)

# Assigns all salutations that are not included in the given list to the category of "Other".
salutations[!(salutations %in% c("Mr", "Dr", "Master", 
                                 "Miss", "Mrs", "Rev"))] <- "Other"



# 5

#mutate the titanicTib dataframe to create a new column "FamSize" equal to the sum of SibSp and Parch
titanicWithSals <- titanicTib %>% 
  mutate(FamSize = SibSp + Parch)

#create a new column "Salutation" with the salutations vector
titanicWithSals <- titanicWithSals %>%
  mutate(Salutation = salutations)

#create a vector with the names of the factors to be included in the dataframe
fctrsInclSals <- c("Survived", "Sex", "Pclass", "Salutation")

#mutate the dataframe to convert the specified factors to factors
titanicWithSals <- titanicWithSals %>%
  mutate_at(.vars = fctrsInclSals, .funs = factor) %>%
  select(Survived, Pclass, Sex, Age, Fare, FamSize, Salutation)

#create a classification task from the dataframe
titanicTaskWithSals <- makeClassifTask(data = titanicWithSals, 
                                       target = "Survived")

#create an imputation wrapper for logistic regression
logRegWrapper <- makeImputeWrapper("classif.logreg",
                                   cols = list(Age = imputeMean()))

#create a resampling descriptor for 10-fold cross validation with 50 repetitions with stratification
kFold <- makeResampleDesc(method = "RepCV", folds = 10, reps = 50, 
                          stratify = TRUE)

#resample the logistic regression model using the specified resampling descriptor
logRegWithSals <- resample(logRegWrapper, titanicTaskWithSals, 
                           resampling = kFold, 
                           measures = list(acc, fpr, fnr))
logRegWithSals                