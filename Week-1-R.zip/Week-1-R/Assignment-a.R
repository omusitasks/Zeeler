###############################################
#          SOURCE CODE FOR Assignment(a)         #
###############################################


# Set working environment
setwd("C:/Users/users/Downloads/Week-1-R")

#Load the required packages 
library(dplyr) 
library(ggplot2)

#Load the titanic dataset
titanic_data <- read.csv("titanic.csv")

#View the dataset 
head(titanic_data)


#Exploring the dataset
summary(titanic_data)

#Exploring the survival outcome
table(titanic_data$Survived)

#Exploring the survival rate by gender
table(titanic_data$Sex, titanic_data$Survived)

#Visualizing the survival rate by gender
ggplot(data = titanic_data, aes(x = Sex, fill = factor(Survived))) + 
  geom_bar(position = "dodge") +
  labs(title = "Survival Rate by Gender", x = "Gender", y = "Number of Passengers")


#Exploring the survival rate by age
table(titanic_data$Age, titanic_data$Survived)

#Visualizing the survival rate by age
ggplot(data = titanic_data, aes(x = Age, fill = factor(Survived))) + 
  geom_histogram(position = "dodge") +
  labs(title = "Survival Rate by Age", x = "Age", y = "Number of Passengers")


#Exploring the survival rate by class
table(titanic_data$Pclass, titanic_data$Survived)

#Visualizing the survival rate by class
ggplot(data = titanic_data, aes(x = Pclass, fill = factor(Survived))) + 
  geom_bar(position = "dodge") +
  labs(title = "Survival Rate by Class", x = "Class", y = "Number of Passengers")



#Exploring the survival rate by fare
table(titanic_data$Fare, titanic_data$Survived)

#Visualizing the survival rate by fare
ggplot(data = titanic_data, aes(x = Fare, fill = factor(Survived))) + 
  geom_histogram(position = "dodge") +
  labs(title = "Survival Rate by Fare", x = "Fare", y = "Number of Passengers")

# 
# From the above analysis, it appears that the most important predictors of survival of Titanic passengers were gender, age, class, and fare. Females were more likely to survive than males. Young passengers were more likely to survive than older passengers. Passengers in first class were more likely to survive than passengers in lower classes, and passengers with higher fares were more likely to survive than passengers with lower fares.