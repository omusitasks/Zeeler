###############################################
#          SOURCE CODE FOR CHAPTER 1          #
###############################################


# Create three vectors
numberOfLegs <- c(4, 4, 0)
climbsTrees <- c(TRUE, FALSE, TRUE)

# Loop through the vectors
for (i in 1:3) {
  # If the number of legs is 4
  if (numberOfLegs[i] == 4) {
    # If the animal climbs trees
    if (climbsTrees[i]) 
      # Print cat
      print("cat") 
    # Else
    else 
    # Print dog
    print("dog")
  } 
  # Else
  else 
  # Print snake
  print("snake")
}
