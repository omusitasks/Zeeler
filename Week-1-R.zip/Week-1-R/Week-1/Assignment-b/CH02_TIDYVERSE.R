###############################################
#          SOURCE CODE FOR CHAPTER 2          #
###############################################

# INSTALLING AND LOADING THE TIDYVERSE ----
# install and load together (recommended)
installMe <- FALSE
if(installMe) {
install.packages('tidyverse', repos = "http://cran.us.r-project.org")
}
#install.packages("tidyverse") # only needed once on any R installation
library(tidyverse)

# or install and load individually as needed
# install.packages(c("tibble", "dplyr", "ggplot2", "tidyr"))
# library(tibble)
# library(dplyr)
# library(ggplot2)
# library(tidyr)

# CREATING TIBBLES WITH tibble() ----
myTib <- tibble(x =  1:4, 
                y = c("london", "beijing", "las vegas", "berlin"))

myTib

# CONVERTING DATA FRAMES TO TIBBLES WITH as_tibble() ----

# creates dataframe with two columns x and y containing numric and string respectively 
# and store data in myDF object
myDf <- data.frame(x =  1:4, 
                   y = c("london", "beijing", "las vegas", "berlin"))

# Converts myDf dataframe to tibble
dfToTib <- as_tibble(myDf)

# prints dfToTib tibble
dfToTib

# TIBBLES DON'T CONVERT STRINGS TO FACTORS BY DEFAULT ----

# creates dataframe with two columns x and y containing numric and string respectively 
# and store data in myDF object
myDf <- data.frame(x =  1:4, 
                   y = c("london", "beijing", "las vegas", "berlin"))


# creates dataframe with two columns x and y containing numric and string respectively 
# and store data in myDF object
# finally the code Specify the strings in the y column should not be treated as factors
myDfNotFactor <- data.frame(x =  1:4, 
                            y = c("london", "beijing", "las vegas", "berlin"),
                            stringsAsFactors = FALSE)

myTib <- tibble(x =  1:4, 
                y = c("london", "beijing", "las vegas", "berlin"))

# Check the class of the column y in myDf dataframe
class(myDf$y)

# Check the class of the column y in myDfNotFactor dataframe
class(myDfNotFactor$y)

# Check the class of the column y in myTib dataframe
class(myTib$y)

# IF YOU WANT TO CREATE A FACTOR, WRAP THE c() FUNCTION INSIDE factor() ----
myTib <- tibble(x =  1:4, 
                y = factor(c("london", "beijing", "las vegas", "berlin")))

# print the myTib datafrane
myTib

# PRINTING A TIBBLE KEEPS THE OUTPUT CONCISE ----

# load the starwars dataframe
data(starwars)

# View the dataframe
starwars

# convert the dataset to a dataframe
as.data.frame(starwars)

# SUBSETTING WITH [ ALWAYS RETURNS ANOTHER TIBBLE ----

# Code that retrieves the first column of myDf dataframe
myDf[, 1]

# Code that retrieves the first column of myTib dataframe
myTib[, 1]

# Code that retrieves the first element of myTib dataframe
myTib[[1]]

# Code that retrieves the element named "x" of myTib dataframe
myTib$x 

# VARIABLE CREATION IN tibble() IS SEQUENTIAL ----
# Create a tibble called sequentialTib
sequentialTib <- tibble(
  # Specify the columns and their respective values 
  nItems = c(12, 45, 107), 
  cost = c(0.5, 1.2, 1.8), 
  # Calculate the total worth by multiplying the number of items with their respective cost
  totalWorth = nItems * cost
)

# View the tibble
sequentialTib

# EXPLORING THE CO2 DATASET ----

# Load CO2 data
data(CO2)

# convert co2 as tibble
CO2tib <- as_tibble(CO2)

#view co2 data
CO2tib

# SELECTING COLUMNS WITH select() ----
# Select columns 1, 2, 3, and 5 from the CO2tib data set and save the selected data set as selectedData
selectedData <- select(CO2tib, 1, 2, 3, 5)

# view the selected data
selectedData

# FILTERING DATA WITH filter() ----

# Filter the data from the object "selectedData"
filteredData <- 
  # where the "uptake" is greater than 16
  filter(selectedData, uptake > 16)
# and store the data in filterData object

# view the filtered data
filteredData

# GROUPING DATA WITH group_by() ----

# Group the filterData dataframe by column plant
groupedData <- group_by(filteredData, Plant)

# view the groupedData
groupedData

# SUMMARIZING DATA WITH summarize() ----

#Summarize the grouped data by calculating the mean and standard deviation of 'uptake'
summarizedData <- summarize(groupedData, meanUp = mean(uptake), 
                            sdUp = sd(uptake))

# View summarizedData dataframe
summarizedData

# CREATING NEW VARIABLES WITH mutate() ----

#mutate is used to add a CV column to the dataframe
mutatedData <- mutate(summarizedData,  CV = (sdUp / meanUp) * 100)

# view mutatedData 
mutatedData

# ARRANGING DATA WITH arrange() ----

# arrange the mutatedData dataset by CV
arrangedData <- arrange(mutatedData, CV)

# View arrangeData
arrangedData

# USING THE %>% ("PIPE") OPERATOR ----

# Calculate the mean of the following numbers
1, 4, 7, 3, 5 %>% 
  # Used the pipe operator to pass the numbers
  mean() 
# Used the mean function to calculate the mean of the numbers

# COMBINING DPLYR VERBS WITH THE %>% OPERATOR ----

# Select columns 1 to 3 and 5 from the CO2tib dataset
arrangedData <- CO2tib %>%
  select(c(1:3, 5)) %>%
  # Filter the dataset to include only rows where uptake is greater than 16
  filter(uptake > 16) %>%
  # Group the dataset by Plant column
  group_by(Plant) %>%
  # Calculate the mean and standard deviation of uptake for each Plant
  summarize(meanUp = mean(uptake), sdUp = sd(uptake)) %>%
  # Calculate the coefficient of variation for each Plant
  mutate(CV = (sdUp / meanUp) * 100) %>%
  # Arrange the dataset by coefficient of variation
  arrange(CV)


# view the arrangedData
arrangedData

# PLOTTING THE IRIS DATASET WITH ggplot() ----

# load iris dataset
data(iris)

# Create a plot with data from the iris dataset, using Sepal Length for the x-axis and Sepal Width for the y-axis
myPlot <- ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width))+
# Add points to the plot
myPlot + geom_point()+
# Use a black and white theme
myPlot + theme_bw()

# view the myPlot dataset
myPlot

# ADDING ADDITIONAL GEOMETRIC OBJECTS ("GEOMS") AS PLOT LAYERS ----

# Create a ggplot object
myPlot <- ggplot(data = mtcars, aes(x = mpg, y = wt))+
# Add a density layer
myPlot + geom_density_2d()+
# Add a smooth layer
myPlot + geom_smooth()

# MAPPING SPECIES TO THE SHAPE AND COLOR AESTHETICS ----

# The code below produces a scatter plot of Sepal Length vs. Sepal Width for the Iris dataset
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width, shape = Species)) + # This line creates the initial plot and assigns the variables for the x and y axis and the shape of the points in the plot
  # This line adds the points in the plot
  geom_point() + 
  # This line adds a theme of black and white to the plot
  theme_bw() 


# Add a color aesthetic to the graph based on the Species variable
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width, col = Species)) +
  # This line adds the points in the plot
  geom_point() + 
  # This line adds a theme of black and white to the plot
  theme_bw() 

# FACETING BY SPECIES ----

# Create a ggplot object from the iris dataset
ggplot(iris, aes(x = Sepal.Length, y = Sepal.Width)) +
  # Split the plot into three facets according to the Species
  facet_wrap(~ Species) +
  geom_point() + 
  # This line adds a theme of black and white to the plot
  theme_bw() 


# CREATING AN UNTIDY TIBBLE ----

# Create a tibble called patientData that contains three variables and three observations
patientData <- tibble(Patient = c("A", "B", "C"),
                      Month0 = c(21, 17, 29),
                      Month3 = c(20, 21, 27),
                      Month6 = c(21, 22, 23))

# view the patientData
patientData

# CONVERTING UNTIDY DATA TO TIDY FORMA USING gather() ----
tidyPatientData <- gather(patientData, key = Month, 
                          value = BMI, -Patient)

# view the tidyPatientData
tidyPatientData

# or the same can be achieved with:
gather(patientData, key = Month, value = BMI, Month0:Month6)
# or:
gather(patientData, key = Month, value = BMI, c(Month0, Month3, Month6))

# CONVERTING DATA INTO WIDE FORMAT WITH spread() ----
spread(tidyPatientData, key = Month, value = BMI)

# EXAMPLE OF PURE FUNCTION VS ONE WITH SIDE EFFECTS ----

# assigns value 20 to variable a
a <- 20

# This code  a function called pure that adds 1 to the variable a and returns the new value of a.
pure <- function() {
  a <- a + 1
  a
}

# The code snippet below creates a function called side_effect that adds 1 to the variable a and assigns the new value to the global environment.
side_effect <- function() {
  a <<- a + 1
  a
}

# This line of code returns a vector containing the output of the function pure twice.
c(pure(), pure())

c(side_effect(), side_effect())
# This line of code returns a vector containing the output of the function side_effect twice.

# USING purrr FUNCTIONS FOR VECTORIZATION ----

# Create a list called listOfNumerics from random numbers
listOfNumerics <- list(a = rnorm(5), 
                       b = rnorm(9),
                       c = rnorm(10))

# view listofNumerics
listOfNumerics

# The line of code below creates an empty list with a length of 3
elementLengths <- vector("list", length = 3)

# This code line iterates through the list of numerics and store the length of each element in the new list
for(i in seq_along(listOfNumerics)) {
  elementLengths[[i]] <- length(listOfNumerics[[i]])
}

# View the new list
elementLengths

# Use the map() function to find the length of each element in the list of numerics
map(listOfNumerics, length)

# Use the map_int() function to find the length of each element in the list of numerics
map_int(listOfNumerics, length)

# Use the map_chr() function to find the length of each element in the list of numerics
map_chr(listOfNumerics, length)


#DANGER! conversion 
print("Skipping attempt to convert integers to logicals")
#map_lgl(listOfNumerics, length)



#Create a list of numeric objects
listOfNumerics <- list(rnorm(100, mean = 5, sd = 3),
                       rnorm(200, mean = 10, sd = 10),
                       rnorm(300, mean = 20, sd = 5))

#Create a function which takes a list and length as arguments and returns a data frame
map_df <- function(listOfNumerics, length){
  map_df(listOfNumerics, ~data.frame(x = .x, length = length))
}

#Create a new list by adding 2 to each element of the existing list
map(listOfNumerics, ~. + 2)

#Create a 1 by 3 plot
par(mfrow = c(1, 3))

#Create a histogram for each element of the list
walk(listOfNumerics, hist)

#Create a histogram and add a title to each element of the list
iwalk(listOfNumerics, ~hist(.x, main = .y))

#Create a list of multipliers
multipliers <- list(0.5, 10, 3)

#Create a new list by multiplying each element of the list by the corresponding multiplier
map2(.x = listOfNumerics, .y = multipliers, ~.x * .y)

#Create a data frame of arguments
arguments <- expand.grid(n = c(100, 200),
                         mean = c(1, 10),
                         sd = c(1, 10))

#Create a 2 by 4 plot
par(mfrow = c(2, 4))

#Create a histogram for each element of the list and add a title to each element
pmap(arguments, rnorm) %>%
  iwalk(~hist(.x, main = paste("Element", .y)))


# SOLUTIONS TO EXERCISES ----
# 1

# load tidyverse library
library(tidyverse)

# load mtcars dataset
data(mtcars)

# convert mtcars dataset as tibble and store it in mtcarsTib object
mtcarsTib <- as_tibble(mtcars)

# view the summary of mtcarsTib object
summary(mtcarsTib)

# 2

# Removing columns 7 and 8 from mtcarsTib (using column names)
select(mtcarsTib, c(-qsec, -vs))
# or

# Removing columns 7 and 8 from mtcarsTib (using indexes)
select(mtcarsTib, c(-7, -8))







# 3

# Filter the data frame "mtcarsTib" by excluding observations with 8 cylinders
filter(mtcarsTib, cyl != 8)


# 4

mtcarsTib %>%
  # group by gear
  group_by(gear) %>%
  # Summarize the dataset to find the median mpg and disp
  summarize(mpgMed = median(mpg), dispMed = median(disp)) %>%
  # Create a new column called mpgOverDisp which is the ratio of mpgMed and dispMed
  mutate(mpgOverDisp = mpgMed / dispMed)

# 5

# Create a ggplot object with mtcarsTib dataset, mapping drat and wt to the x and y axis 
# respectively and colour according to carb 
ggplot(mtcarsTib, aes(drat, wt, col = carb)) +
  # Add a geom_point layer to the plot
  geom_point()

# Create a ggplot object with mtcarsTib dataset, mapping drat and wt to the x and y axis 
#respectively and colour according to carb 
ggplot(mtcarsTib, aes(drat, wt, col = as.factor(carb))) +
  # Add a geom_point layer to the plot
  geom_point()


# 6
# First, gather columns from mtcarsTib into key-value pair format
mtcarsTib_gather <- gather(mtcarsTib, 
                           # Next line specify the column to store variable names as "variable"
                           key = "variable", 
                           # Next line specify the column to store values as "value"
                           value = "value", 
                           # last line specify columns to gather
                           c(vs, am, gear, carb))
# or
gather(mtcarsTib, key = "variable", value = "value", c(8:11))




# 7

#Apply the map_lgl function to the mtcars data frame
map_lgl(mtcars, ~sum(.) > 1000)
# or
map_lgl(mtcars, function(.) sum(.) > 1000)






