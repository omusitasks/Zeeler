# first we import required libraries
import os # to load files from the system
import matplotlib.pyplot as plt # for plotting
from skimage import io, color, filters, feature  # Importing the canny function from the feature module

# we define edge_detection using Sobel and Canny
def edge_detection(image_path):
    # Read the image from the file path
    image = io.imread(image_path)

    # Convert to grayscale for edge detection
    gray_image = color.rgb2gray(image)  

    # Sobel edge detection
    sobel_edges = filters.sobel(gray_image)

    # Canny edge detection
    canny_edges = feature.canny(gray_image)  # Using canny from the feature module

    return sobel_edges, canny_edges

# Get the current directory
# we need to fetch the current working directory in order to access the image files
current_directory = os.getcwd()  

# Image filenames
image_files = ['can.jpg', 'wrench1.jpg', 'wrench2.jpg']

# We define a for loop to process and save results for each image
for filename in image_files:
    image_path = os.path.join(current_directory, filename)
    if os.path.exists(image_path):
        sobel_edges, canny_edges = edge_detection(image_path)

        # Save and display Sobel edges
        plt.imshow(sobel_edges, cmap='gray')
        plt.title(f'Sobel Edge Detection - {filename}')
        plt.savefig(f'sobel_{filename}')

        # Save and display Canny edges
        plt.imshow(canny_edges, cmap='gray')
        plt.title(f'Canny Edge Detection - {filename}')
        plt.savefig(f'canny_{filename}')

        # Display the original image for comparison
        plt.imshow(io.imread(image_path))
        plt.title(f'Original Image - {filename}')
        plt.show()
    else:
        # if the image files are not found in the current working directory
        print(f"File '{filename}' not found in directory: {current_directory}")

        
