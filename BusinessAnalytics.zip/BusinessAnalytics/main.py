# Load required packages
import matplotlib.pyplot as plt
import pandas as pd

# load data googleplaystore.csv dataset
data = pd.read_csv('googleplaystore.csv')   

# get the first 6 rows in the dataframe
data.head()


print("Attribute Name".ljust(20), "Data Type".ljust(20))
print("-"*40)
for col in data.columns:
    print(col.ljust(20), str(data[col].dtype).ljust(20))



# print(data.dtypes)
# Data Transformation/Exploratory data Analysis
# Data cleaning

# # Replace all NaN elements with 0 
# data.fillna(0)

# # Remove the $ sign in the price variable
# # data['Price'] = data['Price'].str.replace('$', '')
# data['Price'] = data['Price'].astype(str).str.replace("$", "")   

# # Remove the + ign in the Installs variable
# data['Installs'] = data['Installs'].astype(str).str.replace("+", "")  

# # Remove the 'Everyone' sign in the price variable
# data['Price'] = data['Price'].str.replace('Everyone', '')
# data['Installs'] = data['Installs'].str.replace('Everyone', '')
# data['Reviews'] = data['Reviews'].str.replace('Everyone', '')

# # convert price to float
# data['Price'] = pd.to_numeric(data['Price'],errors='coerce')
# # data['Installs'] = pd.to_numeric(data['Installs'],errors='coerce')

# # Convert the Installs column to float
# # data['Installs'] = data['Installs'].astype(float)

# # Replace the comma (,) with empty string
# data['Installs'] = data['Installs'].str.replace(',', '')

# # Replace 'Free' with 0
# data['Installs'] = data['Installs'].replace('Free', 0.0)

# # Convert the Installs column to float
# data['Installs'] = data['Installs'].astype(float)


# # Remove the M sign in the size variable
# data['Size'] = data['Size'].astype(str).str.replace("M","")

# # convert size to float
# data['Size'] = pd.to_numeric(data['Size'],errors='coerce')

# # check the data types after convertion
# print(data.dtypes)


# # # 1. What is the average rating for an App in the Google Play Store?

# # #1 Average Rating
# # avg_rating = data['Rating'].mean()
# # print('The Average Rating for an App in the Google Play Store is: ', avg_rating)
   

# # import matplotlib.pyplot as plt
# # plt.style.use('seaborn-whitegrid')

# # # Create a histogram
# # data['Rating'].hist(bins=30)
# # plt.xlabel('Rating')
# # plt.ylabel('Frequency')
# # plt.title('Google Play Store App Rating Histogram')
# # plt.show()

# # # 2. What is the average size of an App in the Google Play Store?

# # #2 Average Size
# # avg_size = data['Size'].mean()
# # print('The Average Size of an App in the Google Play Store is: ', avg_size)


# # # Create a histogram
# # data['Size'].hist(bins=30)
# # plt.xlabel('Size')
# # plt.ylabel('Frequency')
# # plt.title('Google Play Store App Size Histogram')
# # plt.show()

# # # 3. What is the most popular category of App in the Google Play Store?

# # #3 Most Popular Category
# # most_popular_cat = data['Category'].mode()
# # print('The Most Popular Category of App in the Google Play Store is: ', most_popular_cat)


# # import matplotlib.pyplot as plt

# # # Get the value counts of the categorical variables
# # category_counts = data['Category'].value_counts()

# # # Create a bar chart
# # category_counts.plot(kind='bar')
# # plt.xlabel('Category')
# # plt.ylabel('Count')
# # plt.title('Google Play Store App Category Counts')
# # plt.show()


# # # What is the average price of an App in the Google Play Store?

# # #4 Average Price
# # avg_price = data['Price'].mean()
# # print('The Average Price of an App in the Google Play Store is: ', avg_price)
  


  
# # # What is the most popular content rating for an App in the Google Play Store?

# # #5 Most Popular Content Rating
# # most_popular_con_rating = data['Content Rating'].mode()
# # print('The Most Popular Content Rating for an App in the Google Play Store is: ', most_popular_con_rating)          

# # # Create a histogram
# # data['Content Rating'].value_counts().plot(kind='bar', title='Content Rating')
# # plt.xlabel('Content Rating')
# # plt.ylabel('Frequency')
# # plt.show()


# # # Create a histogram
# # data['Type'].value_counts().plot(kind='bar', title='Content Rating')
# # plt.xlabel('Content Rating')
# # plt.ylabel('Frequency')
# # plt.show()

# # # How does the number of reviews for an App in the Google Play Store correlate with the rating?

# # plt.scatter(data["Reviews"], data["Rating"])
# # plt.xlabel("Number of Reviews")
# # plt.ylabel("Rating")
# # plt.title("Number of Reviews vs Rating")
# # plt.show()

# # # How does the size of an App in the Google Play Store correlate with the number of downloads?

# # plt.scatter(data["Size"], data["Installs"])
# # plt.xlabel("Size (in MB)")
# # plt.ylabel("Number of Downloads")
# # plt.title("Size vs Number of Downloads")
# # plt.show()

# # ## Number of App Installs by Type(Free/Paid)

# # # Get the required columns from the dataset
# # installs = data['Installs']
# # types = data['Type']

# # # Create lists for each type
# # free_installs = []
# # paid_installs = []

# # # Append install values to correct list
# # for i in range(len(installs)):
# #     if types[i] == "Free":
# #         free_installs.append(installs[i])
# #     else:
# #         paid_installs.append(installs[i])

# # # Create a bar chart
# # plt.bar(["Free", "Paid"], [sum(free_installs), sum(paid_installs)])
# # plt.title("Number of Installs by Type")
# # plt.xlabel("Type")
# # plt.ylabel("Number of Installs")

# # # Show chart
# # plt.show()

# # # Models and Analysis

# # # Predictive:
    
# # # 1. What is the prediction for the number of reviews of an App in the Google Play Store based on its 
# # # size, category, price, and content rating?

# # # Model 1: Predicting Reviews
# # # Import necessary packages
# # from sklearn.model_selection import train_test_split 
# # from sklearn.linear_model import LinearRegression

# # # Get the features and labels
# # X = data[['Size', 'Category', 'Price', 'Content Rating']]
# # y = data['Reviews']

# # # Split the data into training and testing sets
# # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# # # Fit the model
# # model = LinearRegression()
# # # model.fit(X_train, y_train)

# # # Predict using the model
# # # y_pred = model.predict(X_test)

# # # 3. What is the prediction for the number of installs of an App in the Google Play Store based on its 
# # # size, category, price, and content rating?

# # # Model 3: Predicting Installs
# # # Import necessary packages
# # from sklearn.model_selection import train_test_split 
# # from sklearn.linear_model import LinearRegression

# # # Get the features and labels
# # X = data[['Size', 'Price']]
# # y = data['Installs']


# # # Split the data into training and testing sets
# # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)


# # # Fit the model
# # model = LinearRegression()
# # # model.fit(X_train, y_train)

# # # Predict using the model
# # # y_pred = model.predict(X_test)

