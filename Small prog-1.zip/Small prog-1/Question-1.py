# -*- coding: utf-8 -*-
"""
Created on Thu Nov 16 08:05:07 2023

@author: 
"""



def get_divisors_sum(n):
    divisors_sum = 1  # 1 is always a divisor
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            divisors_sum += i
            if i != n // i:  
                divisors_sum += n // i
    return divisors_sum

def is_perfect_number(num):
    return num == get_divisors_sum(num)

count = 0
number = 2  # here, start checking from 2
while count < 5:
    if is_perfect_number(number):
        print(number, "is a perfect number")
        count += 1
    number += 1

