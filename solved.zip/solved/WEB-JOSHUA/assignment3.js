
var nsProducts = ["Turmeric Curcumin", "Joint Exercise", "Vegan D", "Vegan K", "Well Balanced Diet", "Muscle Soreness Bundle"]; // sample Products to start with
var proposedProduct;

//**************************Part 1 **************************/

  
function addProduct() {
    // This function is implmented for you
    // reads the value from the newProductId field, 
    let aProduct = document.getElementById("newProductId").value; 
    nsProducts[nsProducts.length] = aProduct; // and adds it at the end of the nsProducts array
    listProducts(); // calls listProducts() to reflect the new <li> on the page
}


function listProducts() {
    let menu = document.getElementById('productsId');
    menu.innerHTML = '';

    for (let i = 0; i < nsProducts.length; i++) {
        addItemToList(nsProducts[i]);
    }
}

function addItemToList(new_item) {
    //You should implment this function
//function addItemToList() adds a new <li> with new_item to list it on the page

}

//**************************Part 2 **************************/

function randomProduct() {
    //You should implement this function
// Rhis function dsipays a random product from nsProducts array in the corresponding textbox.


}

function encrypt() {
        //You should implement this function
// function encrypt() iniitally gets the name of the randomely proposed product and encrypt it using 
// Caesar Cipher based on a rotation number entered by the used. 

}


function resetFunc(){
    //You should implement this function
}


