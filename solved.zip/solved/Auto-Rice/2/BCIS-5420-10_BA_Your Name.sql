-- create database to store the tables
create database Northeast;

-- select database to use
use Northeast;

-- Create Guitar table
CREATE TABLE `Guitar` (
    `SerialNumber` INT PRIMARY KEY,
    `Manufacturer` VARCHAR(50),
    `Brand` VARCHAR(50),
    `ModelYear` INT,
    `StringType` VARCHAR(50),
    `Condition` VARCHAR(50),
    `Type` VARCHAR(20),
    `WoodType` VARCHAR(50),
    `Amplifier` VARCHAR(50)
);

-- Create Band table
CREATE TABLE `Band` (
    `BandID` INT PRIMARY KEY,
    `BandName` VARCHAR(100) UNIQUE,
    `Manager` VARCHAR(100)
);

-- Create BandMember table
CREATE TABLE `BandMember` (
    `BandID` INT,
    `MemberName` VARCHAR(100),
    FOREIGN KEY (`BandID`) REFERENCES `Band`(`BandID`)
);

-- Create Concert table
CREATE TABLE `Concert` (
    `ConcertID` INT PRIMARY KEY,
    `Date` DATE,
    `Time` TIME,
    `Venue` VARCHAR(100),
    `TourName` VARCHAR(100),
    `TicketPrice` DECIMAL(8,2),
    `ProjectedAttendance` INT
);

-- Create BandGuitarRental table
CREATE TABLE `BandGuitarRental` (
    `BandID` INT,
    `SerialNumber` INT,
    FOREIGN KEY (`BandID`) REFERENCES `Band`(`BandID`),
    FOREIGN KEY (`SerialNumber`) REFERENCES `Guitar`(`SerialNumber`),
    PRIMARY KEY (`BandID`, `SerialNumber`)
);

-- Create BandConcertPerformance table
CREATE TABLE `BandConcertPerformance` (
    `BandID` INT,
    `ConcertID` INT,
    FOREIGN KEY (`BandID`) REFERENCES `Band`(`BandID`),
    FOREIGN KEY (`ConcertID`) REFERENCES `Concert`(`ConcertID`),
    PRIMARY KEY (`BandID`, `ConcertID`)
);

-- Insert records into Guitar table
INSERT INTO `Guitar` (`SerialNumber`, `Manufacturer`, `Brand`, `ModelYear`, `StringType`, `Condition`, `Type`, `WoodType`, `Amplifier`)
VALUES
    (1, 'Gibson', 'Les Paul', 2020, 'Steel', 'Excellent', 'Electric', NULL, 'Marshall'),
    (2, 'Fender', 'Stratocaster', 2019, 'Nylon', 'Good', 'Acoustic', 'Mahogany', NULL),
    (3, 'Taylor', '814ce', 2021, 'Steel', 'Excellent', 'Hybrid', 'Rosewood', 'Fender'),
    (4, 'Martin', 'D-28', 2018, 'Steel', 'Fair', 'Acoustic', 'Spruce', NULL),
    (5, 'Ibanez', 'RG550', 2017, 'Steel', 'Good', 'Electric', NULL, 'Boss');

-- Insert records into Band table
INSERT INTO `Band` (`BandID`, `BandName`, `Manager`)
VALUES
    (1, 'The Rockers', 'John Smith'),
    (2, 'Acoustic Souls', 'Emily Davis'),
    (3, 'Electric Force', 'Michael Johnson'),
    (4, 'Fusion Beats', 'Sophia Lee'),
    (5, 'The Harmonics', 'Daniel Brown');

-- Insert records into BandMember table
INSERT INTO `BandMember` (`BandID`, `MemberName`)
VALUES
    (1, 'Sam Adams'),
    (1, 'Lisa Johnson'),
    (1, 'Tom Davis'),
    (1, 'Emily White'),
    (1, 'Chris Robinson'),
    (2, 'Emma Clark'),
    (2, 'Matthew Turner'),
    (2, 'Olivia Walker'),
    (2, 'David Martin'),
    (2, 'Sophie Harris'),
    (3, 'Alex Garcia'),
    (3, 'Grace Thompson'),
    (3, 'Jacob Rodriguez'),
    (3, 'Natalie Martinez'),
    (4, 'Ethan Wilson'),
    (4, 'Ava Carter'),
    (4, 'Logan Garcia'),
    (4, 'Chloe Allen'),
    (4, 'Ryan King'),
    (5, 'Victoria Lee'),
    (5, 'Isaac Wright'),
    (5, 'Zoe Hill'),
    (5, 'Elijah Parker'),
    (5, 'Nora Collins');

-- Insert records into Concert table
INSERT INTO `Concert` (`ConcertID`, `Date`, `Time`, `Venue`, `TourName`, `TicketPrice`, `ProjectedAttendance`)
VALUES
    (1, '2023-12-01', '20:00:00', 'Houston Music Hall', 'Rock Fest', 25.00, 500),
    (2, '2023-11-28', '19:30:00', 'Dallas Arena', 'Acoustic Nights', 20.00, 300),
    (3, '2023-12-10', '21:00:00', 'Fort Worth Stadium', 'Electric Fusion', 30.00, 400),
    (4, '2023-12-15', '18:45:00', 'Houston Amphitheater', 'Fusion Mix', 22.50, 350),
    (5, '2023-12-05', '20:15:00', 'Dallas Music Center', 'Harmony Showcase', 18.00, 250);

-- Insert records into BandGuitarRental table
INSERT INTO `BandGuitarRental` (`BandID`, `SerialNumber`)
VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5);

-- Insert records into BandConcertPerformance table
INSERT INTO `BandConcertPerformance` (`BandID`, `ConcertID`)
VALUES
    (1, 1),
    (2, 2),
    (3, 3),
    (4, 4),
    (5, 5);
