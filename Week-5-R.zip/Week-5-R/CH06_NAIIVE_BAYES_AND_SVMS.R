###############################################
#          SOURCE CODE FOR CHAPTER 6          #
###############################################

# NAIIVE BAYES # ----
# LOAD PACKAGES ----

# load the mlr package for ml algorithms
library(mlr)

# load the mlr package for data tidying untidy datasets
library(tidyverse)

# LOAD DATA ----

# Load the "HouseVotes84" dataset from the "mlbench" package
data(HouseVotes84, package = "mlbench")

# Convert the "HouseVotes84" dataset into a tibble and assign it to the variable "votesTib"
votesTib <- as_tibble(HouseVotes84)

# Print the "votesTib" tibble
votesTib

# Display the documentation for the "HouseVotes84" dataset from the "mlbench" package
?mlbench::HouseVotes84

# Use the `map_dbl()` function to apply the `sum(is.na(.))` function to each column of the "votesTib" tibble 
# to count the number of missing values for each column and return a named double vector
map_dbl(votesTib, ~ sum(is.na(.)))


# PLOTTING THE DATA ----

# Reshape the "votesTib" tibble from wide to long format by gathering all columns except "Class" into two columns: "Variable" and "Value"
votesUntidy <- gather(votesTib, "Variable", "Value", -Class)

# Create a stacked bar chart using the "votesUntidy" tibble and the `ggplot2` package
ggplot(votesUntidy, aes(Class, fill = Value)) +
  
  # Create a panel of plots, one for each unique value of the "Variable" column, with the y-axis scales free
  facet_wrap(~ Variable, scales = "free_y") +
  
  # This line add a stacked bar chart layer to the plot and normalize the bars to have a height of 1
  geom_bar(position = "fill") +
  
  # This function is used to set the plot theme to a black and white color scheme
  theme_bw()

# Install the e1071 package for bayes
# install.packages("e1071")


#ggsave("CH06_VOTES_MLR.pdf", width = 10, height = 6)

# MAKE TASK AND LEARNER, AND TRAIN MODEL ----

# load the e1071 library
library(e1071)

# Here we create a classification task using the "makeClassifTask()" function from the `mlr` package
# The "data" argument specifies the data used for the task, and the "target" argument specifies the target variable
votesTask <- makeClassifTask(data = votesTib, target = "Class")

# Next we create a classification learner using the "makeLearner()" function from the `mlr` package
# The argument "classif.naiveBayes" specifies the type of learner to create, in this case, a Naive Bayes classifier
bayes <- makeLearner("classif.naiveBayes")

# The line below trains the Naive Bayes classifier on the "votesTask" task using the "train()" function from the `mlr` package
# The "bayes" argument learner is used to fit the model, and the resulting trained model is assigned to the variable "bayesModel"
bayesModel <- train(bayes, votesTask)



# CROSS-VALIDATING THE MODEL ----

# First we create a resampling descriptor for repeated cross-validation with 10 folds and 50 repetitions
# "stratify = TRUE" ensures that the class distribution is maintained in each fold
kFold <- makeResampleDesc(method = "RepCV", folds = 10, reps = 50, stratify = TRUE)

# Next we Resample the "bayes" learner on the "votesTask" task using the specified resampling descriptor and performance measures
bayesCV <- resample(learner = bayes, task = votesTask, resampling = kFold, measures = list(mmce, acc, fpr, fnr))

# Lets Extract the aggregate performance metrics from the resampling results
bayesCV$aggr


# USING THE MODEL TO MAKE

# We first create a tibble with values for a hypothetical politician's voting record
politician <- tibble(V1 = "n", V2 = "n", V3 = "y", V4 = "n", V5 = "n", 
                     V6 = "y", V7 = "y", V8 = "y", V9 = "y", V10 = "y", 
                     V11 = "n", V12 = "y", V13 = "n", V14 = "n", V15 = "y", 
                     V16 = "n")

# This line uses the trained Naive Bayes model to predict the political party of the hypothetical politician
politicianPred <- predict(bayesModel, newdata = politician)

# The we extract the predicted response (i.e., political party) from the prediction object
getPredictionResponse(politicianPred)

# Lastly we extract the trained model object for the Naive Bayes classifier
getLearnerModel(bayesModel)


# SUPPORT VECTOR MACHINE # ----
# LOAD DATA ----

# install kernlab package

# install.packages("kernlab")

# load library kernlab
library(kernlab)

# Load the "spam" dataset from the "kernlab" package and convert it to a tibble
data(spam, package = "kernlab")
spamTib <- as_tibble(spam)

# View the contents of the "spamTib" tibble
spamTib


# CREATE TASK AND LEARNER ----

# Create a classification task object with the "spamTib" tibble and specify the target variable as "type"
spamTask <- makeClassifTask(data = spamTib, target = "type")

# Create a support vector machine (SVM) learner object for classification
svm <- makeLearner("classif.svm")


# TUNE HYPERPARAMETERS ----

# TRAINING FINAL MODEL WITH TUNED HYPERPARAMETERS ----

# Set the hyperparameters of the "svm" learner to the optimal values obtained from tuning
tunedSvm <- setHyperPars(svm, par.vals = tunedSvmPars$x)

# Train a new SVM model with the tuned hyperparameters using the "spamTask" classification task
tunedSvmModel <- train(tunedSvm, spamTask)


# INCLUDING HYPERPARAMETER TUNING INSIDE NESTED CROSS-VALIDATION ----


# W define a resampling method for cross-validation with 3 iterations
outer <- makeResampleDesc("CV", iters = 3)

# Define a wrapper for tuning the support vector machine (SVM) model with cross-validation
svmWrapper <- makeTuneWrapper("classif.svm", resampling = cvForTuning,
                              par.set = svmParamSpace,
                              control = randSearch)

# Next we define the parameter space for the SVM model including kernel type, degree, cost, and gamma
kernels <- c("polynomial", "radial", "sigmoid")
svmParamSpace <- makeParamSet(
  makeDiscreteParam("kernel", values = kernels),
  makeIntegerParam("degree", lower = 1, upper = 3),
  makeNumericParam("cost", lower = 0.1, upper = 10),
  makeNumericParam("gamma", lower = 0.1, upper = 10))

# This line defines the tuning control for randomly searching the parameter space
randSearch <- makeTuneControlRandom(maxit = 20)

# Define a resampling method for holdout validation with a split ratio of 2/3
cvForTuning <- makeResampleDesc("Holdout", split = 2/3)


# Load necessary packages
library(parallel)
library(parallelMap)

# Detect the number of available CPU cores
detectCores()

# Start a socket cluster using all available CPU cores
parallelStartSocket(cpus = detectCores())

# Tune the parameters of the support vector machine (SVM) model using cross-validation
tunedSvmPars <- tuneParams("classif.svm", task = spamTask,
                           resampling = cvForTuning,
                           par.set = svmParamSpace,
                           control = randSearch)

# Stop the socket cluster
parallelStop()

# Print the tuned SVM parameters
tunedSvmPars
tunedSvmPars$x

# Start a socket cluster using all available CPU cores
parallelStartSocket(cpus = detectCores())

# Resample the SVM model with tuned parameters using the outer cross-validation method
cvWithTuning <- resample(svmWrapper, spamTask, resampling = outer)

# Stop the socket cluster
parallelStop()

# Print the resampled results
cvWithTuning







# EXERCISES ----
# 1
# Map a function that counts the number of "y" values in each column of a Tibble
map_dbl(votesTib, ~ length(which(. == "y")))








# 2
# Retrieve the model object fitted with the naive Bayes learner
getLearnerModel(bayesModel)


# the prior probabilities are 0.61 for democrat and 0.39 for republican 
# (at the time these data were collected!)

# the likelihoods are shown in 2x2 tables for each vote






# 3
# Convert all columns of the Tibble to character data type using map function
votesTib[] <- map(votesTib, as.character)

# Replace all NA values in the Tibble with the character "a"
votesTib[is.na(votesTib)] <- "a"

# Convert all columns of the Tibble to factor data type using map function
votesTib[] <- map(votesTib, as.factor)

# Create a classification task with the Tibble as data and "Class" as target variable
votesTask <- makeClassifTask(data = votesTib, target = "Class")

# Create a naive Bayes learner object
bayes <- makeLearner("classif.naiveBayes")

# Define a resampling strategy using repeated cross-validation with stratification
kFold <- makeResampleDesc(method = "RepCV", folds = 10, reps = 50, stratify = TRUE)

# Resample the naive Bayes learner with the classification task and the defined resampling strategy
bayesCV <- resample(learner = bayes, task = votesTask, resampling = kFold,
                    measures = list(mmce, acc, fpr, fnr))

# Print the aggregated performance measures of the resampled model
bayesCV$aggr


# install parallelStartSocket package
# install.packages("parallel") 
# install.packages("foreach")

# load parallelStartSocket package
install.packages("parallelStartSocket", repos = "https://cloud.r-project.org/")

# only a very slight increase in accuracy

# 4
# Define a parameter space for the SVM model with a linear kernel and a cost parameter ranging from 0.1 to 100
svmParamSpace <- makeParamSet(
  makeDiscreteParam("kernel", values = "linear"),
  makeNumericParam("cost", lower = 0.1, upper = 100))

# Define a random search control object with a maximum of 100 iterations
randSearch <- makeTuneControlRandom(maxit = 100)

# Define a holdout resampling strategy with a split of 2/3 for the spam classification task
cvForTuning <- makeResampleDesc("Holdout", split = 2/3)

# Define a cross-validation resampling strategy with 3 iterations for the SVM model
outer <- makeResampleDesc("CV", iters = 3)

# Create a tuned wrapper for the SVM model using the defined resampling strategies and parameter space
svmWrapper <- makeTuneWrapper("classif.svm", resampling = cvForTuning,
                              par.set = svmParamSpace,
                              control = randSearch)

# This line of code Starts a parallel socket for executing the resampling process
parallelStartSocket(cpus = detectCores())

# This line resample the SVM model with the spam classification task and the defined resampling strategies
cvWithTuning <- resample(svmWrapper, spamTask, resampling = outer) # ~1 min

# This function is called Stop the parallel socket
parallelStop()

# Lets print the resampled performance measures of the tuned SVM model
cvWithTuning
