###############################################
#          SOURCE CODE FOR CHAPTER 5          #
###############################################

# LOAD PACKAGES ----
# load the mlr package for ml algorithms
library(mlr)

# load the mlr package for data tidying untidy datasets
library(tidyverse)

# LOAD DATA ----

# Install HDclassif package
install.packages("HDclassif")

# load the wine dataset from HDclassif package
data(wine, package = "HDclassif")

# store wine dataset loaded above into wineTib object
wineTib <- as_tibble(wine)

# display the wineTib tibble results
wineTib

# CLEAN DATA ----
names(wineTib) <- c("Class", "Alco", "Malic", "Ash", "Alk", "Mag", 
                    "Phe", "Flav", "Non_flav", "Proan", "Col", "Hue", 
                    "OD", "Prol")


# convert Class variable in wineTib to a factor type
wineTib$Class <- as.factor(wineTib$Class)

# print the results of wineTib to check the changes made
wineTib

# PLOTTING THE DATA ----
wineUntidy <- gather(wineTib, "Variable", "Value", -Class)


# Create a ggplot object with wineUntidy data frame, set Class as the x-axis and Value as the y-axis
ggplot(wineUntidy, aes(Class, Value)) +
  
  # Create facets for each of the Variables in wineUntidy
  facet_wrap(~ Variable, scales = "free_y") +
  
  # Add a boxplot to the graph
  geom_boxplot() +
  
  # Set a black and white theme
  theme_bw()

# CREATE TASK AND LEARNER, AND TRAIN MODEL ----

# Create a classification task using the wineTib dataset and the target variable "Class"
wineTask <- makeClassifTask(data = wineTib, target = "Class")

# Create a learner for linear discriminant analysis
lda <- makeLearner("classif.lda")

# Train the lda learner using the wineTask dataset
ldaModel <- train(lda, wineTask)


# EXTRACTING DISCRIMINANT FUNCTION SCORES FOR EACH CASE ----

# Get the learner model data
ldaModelData <- getLearnerModel(ldaModel)

# Apply the model to the dataset and create a variable of the predictions
ldaPreds <- predict(ldaModelData)$x

# View the first 6 predictions
head(ldaPreds)


# PLOT DISCRIMINANT FUNCTIONS ----

wineTib %>%  # start with the wineTib dataframe
  mutate(LD1 = ldaPreds[, 1],  # Create new columns for the LDA predictions
         LD2 = ldaPreds[, 2]) %>%  # Take values from ldaPreds
  ggplot(aes(LD1, LD2, col = Class)) +  # Create a plot with the two LDA predictions and color by Class
  geom_point() +  # Plot points 
  stat_ellipse() +  # Calculate an ellipse
  theme_bw()  # Change the theme


# MAKE QDA LEARNER AND TRAIN MODEL----

# create a qda learner
qda <- makeLearner("classif.qda")

# train the model
qdaModel <- train(qda, wineTask)

# CROSS-VALIDATING MODELS ----
#Create a resampling desciption
kFold <- makeResampleDesc(method = "RepCV", folds = 10, reps = 50, 
                          stratify = TRUE)

#Run the resampling on the lda classifier
ldaCV <- resample(learner = lda, task = wineTask, resampling = kFold,
                  measures = list(mmce, acc))

#Run the resampling on the qda classifier
qdaCV <- resample(learner = qda, task = wineTask, resampling = kFold,
                  measures = list(mmce, acc))

#Print the aggregated results for lda
ldaCV$aggr

#Print the aggregated results for qda
qdaCV$aggr

# CALCULATE CONFUSION MATRICES ----

# Calculate the confusion matrix for the linear discriminant analysis (LDA) model
calculateConfusionMatrix(ldaCV$pred, relative = TRUE)

# Calculate the confusion matrix for the quadratic discriminant analysis (QDA) model
calculateConfusionMatrix(qdaCV$pred, relative = TRUE)


# USING THE QDA MODEL TO MAKE PREDICTIONS ----

# Create a tibble with the poison data
poisoned <- tibble(Alco = 13, Malic = 2, Ash = 2.2, Alk = 19, Mag = 100, 
                   Phe = 2.3, Flav = 2.5, Non_flav = 0.35, Proan = 1.7,
                   Col = 4, Hue = 1.1, OD = 3, Prol = 750)

# Use the qdaModel to predict the class of the poison data
predict(qdaModel, newdata = poisoned)


# SOLUTIONS TO EXERCISES ----
# 2
# create data frame of lda predictions
wineDiscr <- wineTib %>% 
  mutate(LD1 = ldaPreds[, 1], LD2 = ldaPreds[, 2]) %>% 
  select(Class, LD1, LD2)

# create classification task
wineDiscrTask <- makeClassifTask(data = wineDiscr, target = "Class")

# create parameter set 
knnParamSpace <- makeParamSet(makeDiscreteParam("k", values = 1:10))

# create gridsearch
gridSearch <- makeTuneControlGrid()

# create resample description
cvForTuning <- makeResampleDesc("RepCV", folds = 10, reps = 20)

# tune params
tunedK <- tuneParams("classif.knn", task = wineDiscrTask, 
                     resampling = cvForTuning, 
                     par.set = knnParamSpace, 
                     control = gridSearch)

# view tuned parameters
tunedK$x

# set hyperparameters
tunedKnn <- setHyperPars(makeLearner("classif.knn"), par.vals = tunedK$x)

# train model
tunedKnnModel <- train(tunedKnn, wineDiscrTask)