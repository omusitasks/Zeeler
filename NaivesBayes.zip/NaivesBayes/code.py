
# # Import required libraries
import numpy as np

# Load the dataset
data = []
with open('all_sentiment_shuffled.txt', encoding='utf-8') as file:
    for line in file:
        data.append(line.strip())


# Preprocess the Dataset
texts = []  # List to store the preprocessed texts
labels = []  # List to store the sentiment labels

for line in data:
    columns = line.split(' ')  # Split line by spaces
    label = columns[1]  # Extract the sentiment label
    text = ' '.join(columns[3:])  # Join the remaining columns to form the text
    texts.append(text)
    labels.append(label)
    
split_point = int(0.80 * len(texts))
train_docs = texts[:split_point]
train_labels = labels[:split_point]
eval_docs = texts[split_point:]
eval_labels = labels[split_point:]


# Print a few examples of the preprocessed texts and their corresponding labels to verify the preprocessing.
for i in range(5):  # Print the first 5 examples
    print("Text:", texts[i])
    print("Label:", labels[i])
    print()



# Python function that uses a training set of documents to estimate the probabilities in the Naive Bayes model

from collections import defaultdict

def train_nb(documents, labels, alpha=1.0):
    word_counts = defaultdict(lambda: {'pos': 0, 'neg': 0})
    class_counts = {'pos': 0, 'neg': 0}

    for doc, label in zip(documents, labels):
        for word in doc:
            word_counts[word][label] += 1
        class_counts[label] += 1

    total_docs = len(documents)
    class_priors = {label: count / total_docs for label, count in class_counts.items()}

    vocabulary = set(word for doc in documents for word in doc)
    vocab_size = len(vocabulary)

    # Apply smoothing
    smoothed_word_counts = defaultdict(lambda: {'pos': alpha, 'neg': alpha})
    for word in vocabulary:
        for label in ['pos', 'neg']:
            smoothed_word_counts[word][label] += word_counts[word][label]

    # Calculate probabilities
    word_probs = defaultdict(lambda: {'pos': 0.0, 'neg': 0.0})
    for word in vocabulary:
        for label in ['pos', 'neg']:
            word_probs[word][label] = smoothed_word_counts[word][label] / (class_counts[label] + alpha * vocab_size)

    return word_probs, class_priors, vocab_size



# Classifying new documents
import math

def score_doc_label(document, label, word_probs, class_priors, vocab_size):
    log_prob = math.log(class_priors[label])
    for word in document:
        if word in word_probs:
            log_prob += math.log(word_probs[word][label])
    return log_prob



import numpy as np

def score_doc_label(document, label, word_probs, class_priors, vocab_size):
    log_prob = 0.0
    for word in document:
        if word in word_probs:
            log_prob += np.log(word_probs[word][label])

    log_prob += np.log(class_priors[label])

    return log_prob



# Sanity check 1. 
word_probs, class_priors, vocab_size = train_nb(train_docs, train_labels)

document = ["great"]
label = "pos"
log_prob = score_doc_label(document, label, word_probs, class_priors, vocab_size)
prob = np.exp(log_prob)
print(f"Log Probability of positive document with the word 'great': {log_prob}")
print(f"Probability of positive document with the word 'great': {prob}")

# OUTPUT
# Log Probability of positive document with the word 'great': -0.6761896870922498
# Probability of positive document with the word 'great': 0.5085510439618088

# Next, based on the function you just wrote, write another function that classifies a new document.

def classify_nb(document, word_probs, class_priors, vocab_size):
    pos_log_prob = score_doc_label(document, "pos", word_probs, class_priors, vocab_size)
    neg_log_prob = score_doc_label(document, "neg", word_probs, class_priors, vocab_size)

    if pos_log_prob > neg_log_prob:
        return "pos"
    else:
        return "neg"


# Sanity check 2. 
word_probs, class_priors, vocab_size = train_nb(train_docs, train_labels)

document1 = ["great"]
classification1 = classify_nb(document1, word_probs, class_priors, vocab_size)
print(f"Classification of document1: {classification1}")

document2 = ["bad"]
classification2 = classify_nb(document2, word_probs, class_priors, vocab_size)
print(f"Classification of document2: {classification2}")



# Evaluating the classifier
## Write a function that classifies each document in the test set and returns the list of predicted sentiment labels.

def classify_documents(docs, word_probs, class_priors, vocab_size):
    predictions = []
    for doc in docs:
        label = classify_nb(doc, word_probs, class_priors, vocab_size)
        predictions.append(label)
    return predictions



# Let's use the classify_documents function to classify all the documents in the test set.

word_probs, class_priors, vocab_size = train_nb(train_docs, train_labels)

test_predictions = classify_documents(eval_docs, word_probs, class_priors, vocab_size)
test_predictions




# # Next, we compute the accuracy, i.e. the number of correctly classified documents divided by the total number of documents.

def accuracy(true_labels, guessed_labels):
    correct = sum(1 for true, guessed in zip(true_labels, guessed_labels) if true == guessed)
    total = len(true_labels)
    accuracy = correct / total
    return accuracy

# Let's compute the accuracy of the classifier on the test set
test_accuracy = accuracy(eval_labels, test_predictions)
print(f"Accuracy on the test set: {test_accuracy}")



# Error analysis
# Find a few misclassified documents and comment on why you think they were hard to classify. For instance, you may select a few short documents where the probabilities were particularly high in the wrong direction.

def error_analysis(true_labels, guessed_labels, documents):
    misclassified_docs = []
    for true, guessed, doc in zip(true_labels, guessed_labels, documents):
        if true != guessed:
            misclassified_docs.append((true, guessed, doc))
    return misclassified_docs

misclassified = error_analysis(eval_labels, test_predictions, eval_docs)

for true, guessed, doc in misclassified:
    print(f"True Label: {true}, Guessed Label: {guessed}")
    print(f"Document: {doc}")
    print("-----")



# Implement the cross-validation method. 
from sklearn.model_selection import KFold

def cross_validation(docs, labels, num_folds):
    kf = KFold(n_splits=num_folds, shuffle=True)
    accuracies = []

    for train_index, eval_index in kf.split(docs):
        train_docs_fold = [docs[i] for i in train_index]
        train_labels_fold = [labels[i] for i in train_index]
        eval_docs_fold = [docs[i] for i in eval_index]
        eval_labels_fold = [labels[i] for i in eval_index]

        word_probs, class_priors, vocab_size = train_nb(train_docs_fold, train_labels_fold)
        fold_predictions = classify_documents(eval_docs_fold, word_probs, class_priors, vocab_size)
        fold_accuracy = accuracy(eval_labels_fold, fold_predictions)
        accuracies.append(fold_accuracy)

    mean_accuracy = np.mean(accuracies)
    std_dev = np.std(accuracies)
    interval = (mean_accuracy - 2 * std_dev, mean_accuracy + 2 * std_dev)

    return mean_accuracy, interval



# Then estimate the accuracy and compute a new interval estimate. A typical value of N would be between 4 and 10.

num_folds = 5
mean_accuracy, interval = cross_validation(train_docs, train_labels, num_folds)
print(f"Mean Accuracy: {mean_accuracy}")
print(f"Interval Estimate: {interval}")





