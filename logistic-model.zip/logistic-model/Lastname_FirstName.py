#!/usr/bin/env python
# coding: utf-8

# Import required packages
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import precision_score, recall_score, f1_score



# Step 1: Load the winequality-red.csv dataset
df = pd.read_csv(r"C:\Users\users\Downloads\winequality-red.csv")
df.head()


# Find the maximum and minimum levels/values in the target column (quality)
max_value = df['quality'].max()
min_value = df['quality'].min()

# Print the results
print("Maximum value:", max_value)
print("Minimum value:", min_value)



# Use the levels to set the low and high quality ranges. In our case, we set 3-5 as low quality and 6-8 as high quality

# Define a lambda function to classify the quality
classify_quality = lambda x: 'Low quality' if x >= 3 and x <= 5 else 'High quality'

# Apply the classification function to the 'quality' column
df['quality_class'] = df['quality'].apply(classify_quality)


# Drop the quality column 

column_to_drop = 'quality'  # Replace with the actual column name
df = df.drop(column_to_drop, axis=1)


# Print the updated DataFrame
df.head()


# Split the data into features (X) and target variable (y)
X = df.drop('quality_class', axis=1)
y = df['quality_class']


# Step 2: Split the Data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# Step 3: Train the Logistic Regression Model
model = LogisticRegression()
model.fit(X_train, y_train)


# Step 4: Make Predictions
y_pred = model.predict(X_test)
print(y_pred)


# Step 5: Evaluate the Model
accuracy = (y_pred == y_test).mean()
print("Accuracy:", accuracy)


# calculating the test scores

## To calculate the test scores for the logistic regression model, we will use additional evaluation metrics such as precision, recall, and F1-score. 
## These metrics will provide a more detailed assessment of our model's performance. 


precision = precision_score(y_test, y_pred, average='weighted')
print("Precision:", precision)

recall = recall_score(y_test, y_pred, average='weighted')
print("Recall:", recall)

f1 = f1_score(y_test, y_pred, average='weighted')
print("F1-score:", f1)




