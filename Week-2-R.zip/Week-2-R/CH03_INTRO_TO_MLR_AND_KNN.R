###############################################
#          SOURCE CODE FOR CHAPTER 3          #
###############################################

# INSTALLING AND LOADING PACKAGES ----
#install.packages("mlr", dependencies = TRUE) # could take several minutes
install.packages("mlr", repos = "http://cran.us.r-project.org", dependencies = TRUE) # could take several minutes
# only needed once on any R installation


library(mlr) # this is to load the mlr package, which contains functions for predictive modelling and machine learning

library(tidyverse) # this is to load the tidyverse package, which contains functions for data wrangling, data vizualization, and data analysis.

# LOADING DIABETES DATA ----
# Load the diabetes data set from the mclust package
install.packages("mclust")
library(mclust)

#diabetes <- MASS::diabetes
diabetes <- data(diabetes)
# Converts the diabetes data set to a tibble
diabetesTib <- as_tibble(diabetes)

# Print a summary of the diabetes tibble
summary(diabetesTib)

# Print the entire diabetes tibble
diabetesTib

# PLOT THE RELATIONSHIPS IN THE DATA ----

ggplot(diabetesTib, aes(x = glucose, y = insulin, col = class)) + 
  geom_point()  +
  theme_bw() 
# The code above creates a scatterplot with glucose levels on the x-axis, insulin levels on the y-axis, and the points are colored by class. 
# The geom_point() function is used to create the scatterplot and the theme_bw() function is used to create a black and white theme.


ggplot(diabetesTib, aes(sspg, insulin, col = class)) + 
  geom_point() +
  theme_bw() 
# The code above creates a scatterplot with serum serum plasma glucose levels on the x-axis, insulin levels on the y-axis, and the points are colored by class.
# The geom_point() function is used to create the scatterplot and the theme_bw() function is used to create a black and white theme.


ggplot(diabetesTib, aes(sspg, glucose, col = class)) + 
  geom_point() +
  theme_bw()
# The code above creates a scatterplot with serum serum plasma glucose levels on the x-axis, glucose levels on the y-axis, and the points are colored by class. 
# The geom_point() function is used to create the scatterplot and the theme_bw() function is used to create a black and white theme.


# DEFINING THE DIABETES TASK ----
# Create a classification task using the data from the diabetesTib dataset and set the target variable to be "class"
diabetesTask <- makeClassifTask(data = diabetesTib, target = "class")

# Print the task
diabetesTask


# DEFINING THE KNN LEARNER ----

# The line of code below Creates an object named "knn" that uses the "classif.knn" classifier with parameter values set to "k" = 2 
# for the k-nearest-neighbors algorithm.
knn <- makeLearner("classif.knn", par.vals = list("k" = 2))

# LISTING ALL OF MLR'S LEARNERS ----

# Here the line of code is trying to access the list of learners in a given class. The class is specified in the parentheses.
listLearners()$class

# or list them by function:
# The code above retrieves the class column from the listLearners function that is passed in the argument "classif". 
# The result is stored in the variable 'class'.
listLearners("classif")$class

# This code will return a list of learners that match the given string "regr". The list will be returned as the "class" attribute of the listLearners() function.
listLearners("regr")$class

# This code line retrieves the class from the listLearners function with the argument "cluster".
listLearners("cluster")$class 

# DEFINE MODEL ----

# TRAINING A KNN MODEL ----
knnModel <- train(knn, diabetesTask)
# knnModel is a model object that is trained on the given diabetesTask dataset using the knn algorithm.

# TESTING PERFORMANCE ON TRAINING DATA (VERY BAD PRACTICE) ----
knnPred <- predict(knnModel, newdata = diabetesTib)
# knnPred is a vector of predictions for the diabetesTib dataset using the knn model.

performance(knnPred, measures = list(mmce, acc))
# This line calculates the performance measures (mmce and acc) of the knnPred predictions using the performance() function.

# PERFORMING HOLD-OUT CROSS-VALIDATION ----
holdout <- makeResampleDesc(method = "Holdout", split = 2/3, 
                            stratify = TRUE)
# holdout is a resampling description object that specifies a holdout cross-validation with 2/3 of the data as the training set and 1/3 as the testing set.

holdoutCV <- resample(learner = knn, task = diabetesTask, 
                      resampling = holdout,
                      measures = list(mmce, acc))
# holdoutCV is a result object that contains the predictions from the holdout cross-validation using the knn algorithm.

holdoutCV$aggr
# This line prints the aggregated performance measures (mmce and acc) of the holdout cross-validation.

calculateConfusionMatrix(holdoutCV$pred, relative = TRUE)
# This line calculates the confusion matrix of the predictions from the holdout cross-validation and prints it as a relative percentage.



# PERFORMING REPEATED K-FOLD CROSS-VALIDATION ----

# Generate a 10 fold cross-validation resampling object with 50 repetitions and stratified sampling
kFold <- makeResampleDesc(method = "RepCV", folds = 10, reps = 50, stratify = TRUE)

# Create a cross-validation resampling using the knn learner, diabetesTask, kFold resampling, and mmce and acc measures
kFoldCV <- resample(learner = knn, task = diabetesTask, resampling = kFold, measures = list(mmce, acc))

# Calculate the aggregated performance measures
kFoldCV$aggr

# Calculate the performance measures for each iteration
kFoldCV$measures.test

# Calculate the relative confusion matrix
calculateConfusionMatrix(kFoldCV$pred, relative = TRUE)



# PERFORMING LEAVE-ONE-OUT CROSS-VALIDATION ----

# Instantiate a resampling description object using Leave-One-Out cross-validation
LOO <- makeResampleDesc(method = "LOO")

# Perform Leave-One-Out cross-validation using a k-nearest neighbors model on the diabetesTask dataset 
# and measure both mean misclassification error and accuracy
LOOCV <- resample(learner = knn, task = diabetesTask, resampling = LOO,
                  measures = list(mmce, acc))

# Print the aggregated results
LOOCV$aggr

# Calculate a confusion matrix for the predicted results and display relative values
calculateConfusionMatrix(LOOCV$pred, relative = TRUE)


# HYPERPARAMETER TUNING OF K ----

#Create a parameter space for the knn model with the values of k from 1 to 10
knnParamSpace <- makeParamSet(makeDiscreteParam("k", values = 1:10))

#Create a grid search object
gridSearch <- makeTuneControlGrid()

#Create a 10-fold cross validation with 20 repetitions
cvForTuning <- makeResampleDesc("RepCV", folds = 10, reps = 20)

#Tune the knn model using the parameter space, cross validation and grid search
tunedK <- tuneParams("classif.knn", task = diabetesTask, 
                     resampling = cvForTuning, 
                     par.set = knnParamSpace, 
                     control = gridSearch)

#Show the results of the tuning
tunedK

#Show the best parameter chosen
tunedK$x

#Create a dataset for plotting
knnTuningData <- generateHyperParsEffectData(tunedK)

#Plot the results of the tuning
plotHyperParsEffect(knnTuningData, x = "k", y = "mmce.test.mean",
                    plot.type = "line") +
  theme_bw()



# TRAINING FINAL MODEL WITH TUNED K ----

# Create a knn learner using makeLearner
# Set the hyperparameters of the knn learner using setHyperPars
tunedKnn <- setHyperPars(makeLearner("classif.knn"), par.vals = tunedK$x)

# Train the knn model using the diabetesTask data and the tuned knn learner
tunedKnnModel <- train(tunedKnn, diabetesTask)



# INCLUDING HYPERPARAMETER TUNING INSIDE NESTED CROSS-VALIDATION ----

# Create a resampling descriptor for the inner resampling
inner <- makeResampleDesc("CV")

# Create a resampling descriptor for the outer resampling with 10 folds and 5 repetitions
outer <- makeResampleDesc("RepCV", folds = 10, reps = 5)

# Create a tuning wrapper for the knn classifier with the inner resampling descriptor
knnWrapper <- makeTuneWrapper("classif.knn", resampling = inner, 
                              par.set = knnParamSpace, 
                              control = gridSearch) 

# Perform a 10-fold repeated cross-validation with the inner resampling descriptor 
cvWithTuning <- resample(knnWrapper, diabetesTask, resampling = outer)

# Print the result of the resampling
cvWithTuning



# USING THE MODEL TO MAKE PREDICTIONS ----

# Create a tibble with glucose, insulin, and sspg values for three new patients
newDiabetesPatients <- tibble(glucose = c(82, 108, 300), 
                              insulin = c(361, 288, 1052),
                              sspg = c(200, 186, 135))

# View the new tibble
newDiabetesPatients

# Use the tunedKnnModel to predict the class of each of the three new patients 
newPatientsPred <- predict(tunedKnnModel, newdata = newDiabetesPatients)

# Convert the prediction into a response of either "diabetic" or "non-diabetic"
getPredictionResponse(newPatientsPred)



# EXERCISES ----
# 1

library(ggplot2)

# This code creates a scatterplot with the variables glucose and insulin on the x and y axis, respectively. 
# The geom_point() function is used to create the scatterplot and the theme_bw() function is used to create a black and white theme.
ggplot(diabetesTib, aes(glucose, insulin, 
                        shape = class)) + 
  geom_point()  +
  theme_bw()


#The code below creates a scatterplot with the variables 'glucose' and 'insulin' from the dataset 'diabetesTib'. 
#The shape and color of the points in the plot are determined by the variable 'class'. 
# The geom_point() function is used to create the scatterplot and the theme_bw() function is used to create a black and white theme.
ggplot(diabetesTib, aes(glucose, insulin, 
                        shape = class, col = class)) + 
  geom_point()  +
  theme_bw()

# 2


# This code creates an object called 'holdoutNoStrat' using the makeResampleDesc() function with the arguments 
# "method = 'Holdout'"  which splits the data into a training and testing set, "split = 0.9" which specifies the percentage of the data to be used as the training set, and "stratify = FALSE" which indicates that the data should not be stratified.
holdoutNoStrat <- makeResampleDesc(method = "Holdout", split = 0.9, 
                            stratify = FALSE)

# 3
#The code above creates a resampling description called 'resampKFold500' that uses the 'RepCV' method. 
# This method is a repetitive cross validation method that repeats the cross validation process 500 times with 3 folds each time. 
# Additionally, the 'stratify' argument is set to TRUE, so the data will be stratified when performing the cross validation.
kFold500 <- makeResampleDesc(method = "RepCV", folds = 3, reps = 500, 
                          stratify = TRUE)

# install.packages("kknn")
library(kknn)
knn <- makeLearner("classif.kknn", predict.type = "prob", library = "class")
# The code line above performs k-fold cross-validation (k = 500) on the dataset "diabetesTask" using the k-nearest neighbors (knn) algorithm. 
# The resampling technique used is kFold500 and the measures of performance evaluated are the misclassification error (mmce) and accuracy (acc). 
# The result of the cross-validation is stored in the object "kFoldCV500".
kFoldCV500 <- resample(learner = knn, task = diabetesTask, 
                    resampling = kFold500, measures = list(mmce, acc))

# The below line of code creates a resampling description that uses repeated cross-validation with 5 repetitions of 3 folds and stratification
kFold5 <- makeResampleDesc(method = "RepCV", folds = 3, reps = 5, 
                             stratify = TRUE)

# The code above creates an object called 'kFoldCV5' which performs 5-fold cross-validation on the knn learner on the diabetes task. 
# It uses the mmce and acc measures to evaluate the accuracy of the model.
kFoldCV5 <- resample(learner = knn, task = diabetesTask, 
                       resampling = kFold5, measures = list(mmce, acc))


# The below line of code uses the kFoldCV500 function to perform k-fold cross validation with 500 folds.
# This method is used to evaluate the performance of a predictive model and can provide an estimate of its accuracy.
kFoldCV500$aggr

# The below line of code uses the kFoldCV5 function to perform k-fold cross validation with 5 folds. 
# This method is used to evaluate the performance of a predictive model and can provide an estimate of its accuracy.
kFoldCV5$aggr


# This line of code uses the calculateConfusionMatrix function to calculate a confusion matrix from the predictions generated by the k-fold cross validation. 
# The relative argument is set to TRUE, which calculates the confusion matrix relative to the total number of predictions made.
calculateConfusionMatrix(kFoldCV500$pred, relative = TRUE)

# 4
# The below line of code creates a resampling description using the leave one out (LOO) method, with stratification enabled. 
# (Stratification is a process of dividing a population into smaller groups, or strata, based on pre-defined characteristics
# in order to ensure that each stratum is adequately represented in the sample.)
makeResampleDesc(method = "LOO", stratify = TRUE)

# The below line of code creates a resampling description using the leave one out (LOO) method with 5 repetitions. 
makeResampleDesc(method = "LOO", reps = 5)

# both will result in an error as LOO cross-validation cannot
# be stratified or repeated

# 5
# Create the iris data set 
data(iris)

# Create a classification task object based on the iris data
irisTask <- makeClassifTask(data = iris, target = "Species")

# Create a parameter set of different k values
knnParamSpace <- makeParamSet(makeDiscreteParam("k", values = 1:25))

# Create a grid search control object
gridSearch <- makeTuneControlGrid()

# Create a 10-fold cross validation resampling object with 20 repetitions
cvForTuning <- makeResampleDesc("RepCV", folds = 10, reps = 20)

# Tune the parameters with knn classifier using the created parameter set, resampling object, and grid search control
tunedK <- tuneParams("classif.knn", task = irisTask, 
                     resampling = cvForTuning, 
                     par.set = knnParamSpace, 
                     control = gridSearch)
# Prints the tunedk
tunedK

#The next line extracts the best parameter values from the tunedK object 
tunedK$x

#The following line generates a data frame which contains information about the effect of the parameters on the model's performance
knnTuningData <- generateHyperParsEffectData(tunedK)

#The plotHyperParsEffect() function creates a plot which shows the effect of the parameters on the model's performance
plotHyperParsEffect(knnTuningData, x = "k", y = "mmce.test.mean",
                    plot.type = "line") +
  theme_bw()

#The setHyperPars() function sets the parameters in the knn learner to the values from the tunedK object
tunedKnn <- setHyperPars(makeLearner("classif.knn"), par.vals = tunedK$x)

#The train() function trains the model using the tunedKnn object
tunedKnnModel <- train(tunedKnn, irisTask)



# 6
#the line of code creates a cross-validation resampling description object
inner <- makeResampleDesc("CV")

#create a holdout resampling description object with a 2/3 split and stratified sampling
outerHoldout <- makeResampleDesc("Holdout", split = 2/3, stratify = TRUE)

#create a tuneWrapper object for knn with inner resampling and knnParamSpace parameter set
knnWrapper <- makeTuneWrapper("classif.knn", resampling = inner, 
                              par.set = knnParamSpace, 
                              control = gridSearch) 

#perform a holdout cross-validation with tuning using knnWrapper
holdoutCVWithTuning <- resample(knnWrapper, irisTask, 
                                resampling = outerHoldout)

#print the resampled results
holdoutCVWithTuning

# 7
# below line of code Set up a 5-fold cross-validation resampling procedure using stratified sampling
outerKfold <- makeResampleDesc("CV", iters = 5, stratify = TRUE)

# Run a k-nearest neighbors resampling procedure with outerKfold as the resampling argument
kFoldCVWithTuning <- resample(knnWrapper, irisTask, 
                              resampling = outerKfold)

# Repeat the same resampling procedure, again using outerKfold as the resampling argument
resample(knnWrapper, irisTask, resampling = outerKfold)

# Repeat the k-nearest neighbors resampling procedure 10 times and save the mmce value each time
kSamples <- map_dbl(1:10, ~resample(
  knnWrapper, irisTask, resampling = outerKfold)$aggr
)

# Set up a 70/30 holdout resampling procedure
outerHoldout <- makeResampleDesc("Holdout", iters = 1, p = 0.7)

# Repeat the k-nearest neighbors resampling procedure 10 times using the outerHoldout resampling procedure and save the mmce value each time
hSamples <- map_dbl(1:10, ~resample(
  knnWrapper, irisTask, resampling = outerHoldout)$aggr
)

# Plot a histogram of the kSamples values
hist(kSamples, xlim = c(0, 0.11))

# Plot a histogram of the hSamples values
hist(hSamples, xlim = c(0, 0.11))

# holdout CV gives more variable estimates of model performance 
           