# First we import the required libraries for the task
import numpy as np # for numerical computations.
from scipy.optimize import minimize_scalar # for scalar optimization.

def coin_weights(alpha, coin_obs_mean, coin_values, print_probs=False):
    with np.errstate(over='ignore', invalid='ignore'):
        exp_alpha_x = np.exp(alpha * coin_values)
        prob_coin = exp_alpha_x / np.sum(exp_alpha_x)
    coin_mean = np.sum(coin_values * prob_coin)
    mean_diff = np.abs(coin_mean - coin_obs_mean)
    
    if not print_probs:
        return mean_diff
    else:
        return {
            "prob_coin": prob_coin,
            "coin_mean": coin_mean,
            "mean_diff": mean_diff
        }

# Let's set the possible coin values and observed mean
coin_values = np.array([1, 5, 10, 25, 50, 100])
coin_obs_mean = 10.3828


# Let's estimate the optimal "alpha" value using a trial-and-error approach as indicated from the instructions
# I Increased the search range and steps to Ensure the minimal difference is no larger than 0.01
alpha_range = np.linspace(-1, 10, 1000000)  # Define a range of alpha values to test
best_alpha = None
min_mean_diff = float('inf')
tolerance = 0.01  # Set the tolerance

# To ensure the minimal difference is no larger than 0.01 we need a for loop to traverse the alpha range
# trial and error
for alpha in alpha_range:
    current_mean_diff = coin_weights(alpha, coin_obs_mean, coin_values)
    
    if current_mean_diff < tolerance:
        best_alpha = alpha
        break

# An if statement to ensure that "minimal difference is no larger than 0.01" has been achieved or not
if best_alpha is not None:
    optimal_results = coin_weights(best_alpha, coin_obs_mean, coin_values, print_probs=True)
    print("Optimal alpha:", best_alpha)
    print("Optimal probabilities:", optimal_results["prob_coin"])
    print("Mean difference:", optimal_results["mean_diff"])
else:
    print("Optimal alpha not found within tolerance.")